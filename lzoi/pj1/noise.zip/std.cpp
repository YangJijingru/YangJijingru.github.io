#include<iostream>
#include<iomanip>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#define rep(i,a,b) for(int i=a;i<=b;i++)
using namespace std;
const int dx[4]={0,1,0,-1};
const int dy[4]={1,0,-1,0};
const int maxn=505;

char st[maxn][maxn];
int x[maxn*maxn],y[maxn*maxn],z[maxn*maxn];
int was[maxn][maxn],noise[maxn][maxn];
int n,m,q,p,cnt=0;
int main()
{
	cin>>n>>m>>q>>p;
	rep(i,0,n-1)scanf("%s",st[i]);
	rep(i,0,n-1)
	    rep(j,0,m-1)
	    	if(st[i][j]>='A'&&st[i][j]<='Z'){
	    		int temp=(st[i][j]-'A'+1)*q;
	    		int head=0,tail=1;
	    		x[0]=i,y[0]=j,z[0]=temp;
	    		was[i][j]=++cnt;
	    		while(head<tail){
	    			noise[x[head]][y[head]]+=z[head];
	    			if(z[head]>=2)
	    				rep(j,0,3){
	    					int xnow=x[head]+dx[j],ynow=y[head]+dy[j];
	    					if(xnow>=0&&ynow>=0&&xnow<n&&ynow<m)
	    						if(st[xnow][ynow]!='*'&&was[xnow][ynow]!=cnt){
	    							x[tail]=xnow,y[tail]=ynow,z[tail]=z[head]>>1;
	    							was[xnow][ynow]=cnt;tail++;
	    						}
	    				}
	    			head++;
	    		}
	  	    }
	int ans=0;
	rep(i,0,n-1)
	    rep(j,0,m-1)if(noise[i][j]>p)ans++;
	cout<<ans<<endl;
	return 0;
}
