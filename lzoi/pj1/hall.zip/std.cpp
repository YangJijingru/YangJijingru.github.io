#include<iostream>
#include<iomanip>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#define rep(i,a,b) for(int i=a;i<=b;i++)  
#define dep(i,a,b) for(int i=a;i>=b;i--)  
using namespace std;  
const int maxn=2006,maxm=5000006;  
struct edge{int u,v;double w;}e[maxm];  
int cnt=0,fa[maxn],x[maxn],y[maxn];  
int n,k;  
inline int cmp(edge x,edge y){return x.w<y.w;}  
inline void ins(int a,int b)  
{  
    double s=sqrt((x[a]-x[b])*(x[a]-x[b])+(y[a]-y[b])*(y[a]-y[b]));  
    cnt++;  
    e[cnt]=(edge){a,b,s};  
}  
inline int find(int x){  
    return x==fa[x]?x:fa[x]=find(fa[x]);  
}  
int main()  
{  
    scanf("%d%d",&n,&k);  
    rep(i,1,n)scanf("%d%d",&x[i],&y[i]);  
    rep(i,1,n)rep(j,i+1,n)ins(i,j);  
    sort(e+1,e+1+cnt,cmp);  
    rep(i,1,n)fa[i]=i;  
    rep(i,1,cnt){  
        int root1=find(e[i].u),root2=find(e[i].v);  
        if(root1!=root2){  
            if(n>k){n--;fa[root1]=root2;}  
        else{printf("%.2lf\n",e[i].w);return 0;}}  
    }  
}  
