#include<iostream>
#include<iomanip>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define dep(i,a,b) for(int i=a;i>=b;i--)
using namespace std;

int n,d,flag,a[1000006];

int main()
{
    cin>>n;
	rep(i,1,n)scanf("%d",&a[i]);
	d=a[2]-a[1];
	rep(i,2,n-1)
	    if(a[i+1]-a[i]!=d)flag=1;
	if(flag==0)cout<<a[n]+d;
	else cout<<a[n];
	return 0;
}
